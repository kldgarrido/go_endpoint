package main

import (
	"github.com/stretchr/testify/assert"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestLoadUserFromJSON(t *testing.T) {

	sjson := `{"name": "kaled", "Email": "kldgarrido@gmail.com", "Password": "12345", "Verified": true, "Phone": "3175212067", "Country": "Colombia", "City": "Bogota", "Address": "Calle 114" }`

	user, err := loadUserFromJSON([]byte(sjson))

	assert.NotNil(t, user)
	assert.Nil(t, err)

	assert.Equal(t, "kaled", user.Name)
}

func TestLoadUserFromRequest(t *testing.T) {
	body := strings.NewReader(`{"name": "kaled", "Email": "kldgarrido@gmail.com", "Password": "12345", "Verified": true, "Phone": "3175212067", "Country": "Colombia", "City": "Bogota", "Address": "Calle 114" }`)
	req := httptest.NewRequest("POST", "http://example.com/foo", body)

	user, err := loadUserFromRequest(req)
	assert.NotNil(t, user)
	assert.Nil(t, err)

	assert.Equal(t, "kaled", user.Name)

}
