package main

import (
	"encoding/json"
	"fmt"
	"github.com/pressly/chi"
	"github.com/pressly/chi/middleware"
	"github.com/pressly/chi/render"
	"github.com/streadway/amqp"
	"gopkg.in/go-playground/validator.v9"
	"io/ioutil"
	"log"
	"net/http"
)

type User struct {
	Name     string `validate:"required"`
	Email    string `validate:"required,email"`
	Password string `validate:"required"`
	Verified bool   `validate:"required"`
	Phone    string `validate:"required"`
	Country  string `validate:"required"`
	City     string `validate:"required"`
	Address  string `validate:"required"`

	validate *validator.Validate `json:"-"`
}

func loadUserFromJSON(jsonData []byte) (*User, error) {
	var user *User

	err := json.Unmarshal(jsonData, &user)
	if err != nil {
		log.Fatalf("Failed to Unmarshal" + err.Error())
		return nil, err
	}

	user.validate = validator.New()
	err = user.validate.Struct(user)
	if err != nil {
		log.Fatalf("Failed to validator" + err.Error())
		if _, ok := err.(*validator.InvalidValidationError); ok {
			fmt.Println(err)
			return nil, err
		}

		for _, err := range err.(validator.ValidationErrors) {

			fmt.Println(err.Namespace())
			fmt.Println(err.Field())
			fmt.Println(err.StructNamespace()) // can differ when a custom TagNameFunc is registered or
			fmt.Println(err.StructField())     // by passing alt name to ReportError like below
			fmt.Println(err.Tag())
			fmt.Println(err.ActualTag())
			fmt.Println(err.Kind())
			fmt.Println(err.Type())
			fmt.Println(err.Value())
			fmt.Println(err.Param())
			fmt.Println()
		}

		// from here you can create your own error messages in whatever language you wish
		return nil, err
	}

	return user, nil
}

func loadUserFromRequest(req *http.Request) (*User, error) {
	body, err := ioutil.ReadAll(req.Body)
	if err != nil {
		return nil, err
	}

	return loadUserFromJSON(body)
}

func renderError(rw http.ResponseWriter, req *http.Request, status int, msg string) {
	render.Status(req, status)
	render.JSON(rw, req, map[string]interface{}{
		"message": msg,
	})
}

func createUser(rw http.ResponseWriter, req *http.Request) {

	user, err := loadUserFromRequest(req)
	if err != nil {
		renderError(rw, req, 400, err.Error())
		return
	}

	err = publishToQueue(user)
	if err != nil {
		renderError(rw, req, 400, err.Error())
		return
	}
}

func main() {

	router := chi.NewRouter()
	router.Use(middleware.Logger)
	router.Use(middleware.Recoverer)

	log.Println("start")

	router.Post("/users", createUser)

	log.Fatal(http.ListenAndServe(":8080", router))
}

func publishToQueue(user *User) error {
	conn, err := amqp.Dial("amqp://guest:guest@localhost:5672/")

	if err != nil {
		return err
	}

	defer conn.Close()

	ch, err := conn.Channel()
	if err != nil {
		return err
	}

	defer ch.Close()

	q, err := ch.QueueDeclare(
		"create_user_queue", // name
		false,               // durable
		false,               // delete when unused
		false,               // exclusive
		false,               // no-wait
		nil,                 // arguments
	)
	if err != nil {
		return err
	}

	body, err := json.Marshal(user)
	if err != nil {
		return err
	}

	err = ch.Publish(
		"",     // exchange
		q.Name, // routing key
		false,  // mandatory
		false,  // immediate
		amqp.Publishing{
			ContentType: "text/plain",
			Body:        body,
		})
	if err != nil {
		return err
	}

	return nil
}
