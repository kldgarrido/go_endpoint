package main

import (
	"github.com/stretchr/testify/assert"
	"testing"
)

func TestLoadUserFromJSON(t *testing.T) {

	sjson := `{"name":"kaled"}`

	user, err := loadUserFromJSON([]byte(sjson))

	assert.NotNil(t, user)
	assert.Nil(t, err)

	assert.Equal(t, "kaled", user.Name)
}

func TestGenerateUUID(t *testing.T) {
	uuid := generateUUID()
	assert.NotNil(t, uuid)
}

func TestConnectToDB(t *testing.T) {
	db, err := connectToDB()
	assert.NotNil(t, db)
	assert.Nil(t, err)
}
