package main

import (
	"log"

	"github.com/streadway/amqp"

	"database/sql"
	"fmt"
	_ "github.com/lib/pq"

	"encoding/json"

	"github.com/satori/go.uuid"
	"golang.org/x/crypto/bcrypt"

	b64 "encoding/base64"
)

func connectToDB() (*sql.DB, error) {
	dbinfo := fmt.Sprintf("user=%s password=%s dbname=%s sslmode=disable",
		DB_USER, DB_PASSWORD, DB_NAME)
	db, err := sql.Open("postgres", dbinfo)
	if err != nil {
		return nil, err
	}

	db.SetMaxIdleConns(100)

	return db, nil
}

func main() {
	conn, err := amqp.Dial("amqp://guest:guest@localhost:5672/")
	if err != nil {
		log.Fatalf("Failed RabbitMQ")
		return
	}
	defer conn.Close()

	ch, err := conn.Channel()
	if err != nil {
		log.Fatalf("Failed to open a channel")
		return
	}

	defer ch.Close()

	q, err := ch.QueueDeclare(
		"create_user_queue", // name
		false,               // durable
		false,               // delete when unused
		false,               // exclusive
		false,               // no-wait
		nil,                 // arguments
	)
	if err != nil {
		log.Fatalf("Failed to declare a queue")
		return
	}

	msgs, err := ch.Consume(
		q.Name, // queue
		"",     // consumer
		true,   // auto-ack
		false,  // exclusive
		false,  // no-local
		false,  // no-wait
		nil,    // args
	)
	if err != nil {
		log.Fatalf("Failed to register a consumer")
		return
	}
	//failOnError(err, "Failed to register a consumer")

	forever := make(chan bool)

	db, err := connectToDB()
	if err != nil {
		log.Fatalf("Failed to connect a db")
		return
	}
	defer db.Close()

	go func() {
		for d := range msgs {
			log.Printf("Received a message: %s %s", d.Body, generateUUID())
			insert(d.Body, db)
		}
	}()

	log.Printf(" [*] Waiting for messages. To exit press CTRL+C")
	<-forever
}

const (
	DB_USER     = "postgres"
	DB_PASSWORD = "postgres"
	DB_NAME     = "phoenix"
)

func insert(body []byte, db *sql.DB) error {

	user, err := loadUserFromJSON(body)
	if err != nil {
		log.Fatalf("Failed to json")
		return err
	}

	id := generateUUID()

	/*
		tblname := "users(id,name, email, password, checking, phone, country, city, address)"
		data := "my_data"
		err = db.Exec(fmt.Sprintf("INSERT INTO %s VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)", pq.QuoteIdentifier(tblname)), id, user.Name, user.Email, user.Password, user.Verified, user.Phone, user.Country, user.City, user.Address)
	*/
	//db.QueryRow("INSERT INTO users(id, name, email, password, checking, phone, country, city, address) VALUES('"+id+"', '"+u.Name+"', '"+u.Email+"', '"+u.Password+"', '"+u.Check+"', '"+u.Phone+"', '"+u.Country+"', '"+u.City+"')")

	_, err = db.Exec(fmt.Sprintf(`
			INSERT INTO
			users(id,name, email, password, verified, phone, country, city, address)
			VALUES($1, $2, $3, $4, $5, $6, $7, $8, $9);`), id, user.Name, user.Email, user.Password, user.Verified, user.Phone, user.Country, user.City, user.Address)

	if err != nil {
		log.Fatalf("Failed to insert" + err.Error())
		return err
	}

	return nil
}

type User struct {
	Name     string
	Email    string
	Password string
	Verified bool
	Phone    string
	Country  string
	City     string
	Address  string
}

func loadUserFromJSON(jsonData []byte) (*User, error) {
	var u *User
	//s := string(jsonData)
	err := json.Unmarshal(jsonData, &u)
	if err != nil {
		log.Fatalf("Failed to Unmarshal" + err.Error())
		return nil, err
	}

	passw, err := bcrypt.GenerateFromPassword([]byte(u.Password), bcrypt.DefaultCost)
	if err != nil {
		log.Fatalf("Failed to GenerateFromPassword" + err.Error())
		return nil, err
	}

	sEnc := b64.StdEncoding.EncodeToString([]byte(passw))
	u.Password = sEnc

	return u, nil
}

func generateUUID() string {
	u1 := uuid.NewV4()
	s := fmt.Sprint(u1)
	return s
}
